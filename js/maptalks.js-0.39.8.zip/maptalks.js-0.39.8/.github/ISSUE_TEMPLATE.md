**maptalks's version and what browser you use?**
----

**Issue description**
----


**Please provide a reproduction URL (on any jsfiddle like site)**
----
