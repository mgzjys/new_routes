export { default as CanvasLayerRenderer } from './CanvasLayerRenderer';
